﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static FD_Parfumeri.Varleklar;

namespace FD_Parfumeri
{
    public partial class MustriForm : Form


    {
        Musteri Musteri { get; set; }

        string server = "127.0.0.1";
        string uid = "19675245019";
        string password = "19675245019";
        string database = "19675245019_frateliParfumleri";

        public MustriForm()
        {
            InitializeComponent();

        }

        private void TmmBtn_Click(object sender, EventArgs e)
        {
           

        }
        private void DisplayMusteriData()
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            string query = "SELECT * FROM musteri";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    musGridView1.DataSource = dataTable;
                }
            }
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {

        }
        public bool UpdateMusteri(int urunId, string urunAd, int urunStok, decimal urunFiyat)
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd= new MySqlCommand("Musteri_Update", connection))
                {
                    cmd.Parameters.AddWithValue("@musteriId", Convert.ToInt32(txtID.Text));
                    cmd.Parameters.AddWithValue("@@musteriAd", txtAD.Text);
                    cmd.Parameters.AddWithValue(" @musteriSoyad", txtSoyad.Text);
                    cmd.Parameters.AddWithValue("@musteriTelefon", txtTelefon.Text);
                    cmd.Parameters.AddWithValue("@musteriAdres", txtAdd.Text);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    return rowsAffected > 0;
                }
            }
        }
        private int GetMusId()
        {

            int musId = 0;


            if (musGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = musGridView1.SelectedRows[0];
                musId = Convert.ToInt32(selectedRow.Cells[0].Value);

                txtID.Text = musId.ToString();


            }



            return musId;
        }


        private void UrunFrm_Load(object sender, EventArgs e)
        {
            DisplayMusteriData();
        }

        private void DuzenleBtn_Click(object sender, EventArgs e)
        {

           
        }


        private void button1_Click(object sender, EventArgs e)
        {
           
        }

       

        private void UrunFrm_Load_1(object sender, EventArgs e)
        {
            DisplayMusteriData();
        }

        private void tamamBtn_Click(object sender, EventArgs e)
        {
            string constring = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            MySqlConnection con = new MySqlConnection(constring);
            con.Open();



            string insertIntoTable = "INSERT INTO musteri (musteriId, musteriAd, musteriSoyad, musteriTelefon,musteriAdres)" +
                " VALUES (@musteriId, @musteriAd, @musteriSoyad, @musteriTelefon,@musteriAdres)";
            using (MySqlCommand cmd = new MySqlCommand(insertIntoTable, con))
            {
                cmd.Parameters.AddWithValue("@musteriId", Convert.ToInt32(txtID.Text));
                cmd.Parameters.AddWithValue("@musteriAd", txtAD.Text);
                cmd.Parameters.AddWithValue("@musteriSoyad", txtSoyad.Text);
                cmd.Parameters.AddWithValue("@musteriTelefon", txtTelefon.Text);
                cmd.Parameters.AddWithValue("@musteriAdres", txtAdd.Text);

                int rowsAffected = cmd.ExecuteNonQuery();
                MessageBox.Show("ürün başarıyla eklendi");
            }
            DisplayMusteriData();

        }

        private void duzenleBtn_Click_1(object sender, EventArgs e)
        {
            int musteriID = Convert.ToInt32(txtID.Text);
            string musteriAd = txtAD.Text;
            string musteriSoyad = txtSoyad.Text;
            string musteriTelefon = txtTelefon.Text;
            string musteriAdres = txtAdd.Text;

            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                int musId = GetMusId();
                string query = "UPDATE musteri SET  MusteriAd = @musteriAdParam, MusteriSoyad = @musteriSoyadParam,musteriTelefon=@musteriTelefonParam,musteriAdres=@musteriAdresParam WHERE MusteriId = " + musId;

                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@musteriIdParam", Convert.ToInt32(txtID.Text));
                    cmd.Parameters.AddWithValue("@musteriAdParam", txtAD.Text);
                    cmd.Parameters.AddWithValue("@musteriSoyadParam", txtSoyad.Text);
                    cmd.Parameters.AddWithValue("@musteriTelefonParam", txtTelefon.Text);
                    cmd.Parameters.AddWithValue("@musteriAdresParam", txtAdd.Text);
                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Musteri updated successfully.");

                        DisplayMusteriData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update Urun.");
                    }
                }
            }
        }

        private void silBtn_Click(object sender, EventArgs e)
        {
            int musID = GetMusId();
            txtID.Text = musID.ToString();

            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = "DELETE FROM musteri WHERE MusteriID = @MusteriID";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@MusteriID", musID);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Musteri deleted successfully.");
                        DisplayMusteriData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete Urun.");
                    }
                }
            }
        }

        private void MustriForm_Load(object sender, EventArgs e)
        {
            DisplayMusteriData();
        }
    }

}

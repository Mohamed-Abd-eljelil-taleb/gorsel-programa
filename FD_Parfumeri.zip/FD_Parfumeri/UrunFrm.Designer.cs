﻿namespace FD_Parfumeri
{
    partial class UrunFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.TmmBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.txtStock = new System.Windows.Forms.NumericUpDown();
            this.txtFiyat = new System.Windows.Forms.NumericUpDown();
            this.urunGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.DuzenleBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txtStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFiyat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(76, 12);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(166, 23);
            this.txtID.TabIndex = 0;
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(76, 56);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(166, 23);
            this.txtAd.TabIndex = 0;
            // 
            // TmmBtn
            // 
            this.TmmBtn.Location = new System.Drawing.Point(76, 182);
            this.TmmBtn.Name = "TmmBtn";
            this.TmmBtn.Size = new System.Drawing.Size(75, 23);
            this.TmmBtn.TabIndex = 1;
            this.TmmBtn.Text = "Tamam";
            this.TmmBtn.UseVisualStyleBackColor = true;
            this.TmmBtn.Click += new System.EventHandler(this.TmmBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Location = new System.Drawing.Point(167, 182);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 1;
            this.CancelBtn.Text = "Iptal";
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // txtStock
            // 
            this.txtStock.Location = new System.Drawing.Point(76, 98);
            this.txtStock.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(166, 23);
            this.txtStock.TabIndex = 2;
            // 
            // txtFiyat
            // 
            this.txtFiyat.Location = new System.Drawing.Point(76, 141);
            this.txtFiyat.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.txtFiyat.Name = "txtFiyat";
            this.txtFiyat.Size = new System.Drawing.Size(166, 23);
            this.txtFiyat.TabIndex = 2;
            // 
            // urunGridView1
            // 
            this.urunGridView1.AllowUserToAddRows = false;
            this.urunGridView1.AllowUserToDeleteRows = false;
            this.urunGridView1.AllowUserToResizeColumns = false;
            this.urunGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.urunGridView1.BackgroundColor = System.Drawing.SystemColors.MenuHighlight;
            this.urunGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.urunGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.urunGridView1.Dock = System.Windows.Forms.DockStyle.Right;
            this.urunGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.urunGridView1.Location = new System.Drawing.Point(258, 0);
            this.urunGridView1.Name = "urunGridView1";
            this.urunGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.urunGridView1.RowTemplate.Height = 25;
            this.urunGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.urunGridView1.Size = new System.Drawing.Size(505, 450);
            this.urunGridView1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(167, 250);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Sil";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DuzenleBtn
            // 
            this.DuzenleBtn.Location = new System.Drawing.Point(76, 250);
            this.DuzenleBtn.Name = "DuzenleBtn";
            this.DuzenleBtn.Size = new System.Drawing.Size(75, 23);
            this.DuzenleBtn.TabIndex = 4;
            this.DuzenleBtn.Text = "Duzenle";
            this.DuzenleBtn.UseVisualStyleBackColor = true;
            this.DuzenleBtn.Click += new System.EventHandler(this.DuzenleBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "AD :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "FIyat :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Stock :";
            // 
            // UrunFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(763, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DuzenleBtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.urunGridView1);
            this.Controls.Add(this.txtFiyat);
            this.Controls.Add(this.txtStock);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.TmmBtn);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.txtID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "UrunFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UrunFrm";
            this.Load += new System.EventHandler(this.UrunFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFiyat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.urunGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtID;
        private TextBox txtAd;
        private Button TmmBtn;
        private Button CancelBtn;
        private NumericUpDown txtStock;
        private NumericUpDown txtFiyat;
        private DataGridView urunGridView1;
        private Button button1;
        private Button DuzenleBtn;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}
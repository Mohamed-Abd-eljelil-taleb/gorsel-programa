﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FD_Parfumeri.Varleklar;

namespace FD_Parfumeri
{
    
    public partial class SatisFrm : Form
    {
        Urun urun { get; set; }
        Musteri ms { get; set; }
        Odeme od { get; set; }
        
        string server = "127.0.0.1";
        string uid = "19675245019";
        string password = "19675245019";
        string database = "19675245019_frateliParfumleri";
        public SatisFrm()
        {
            InitializeComponent();
            urun = new Urun(); 
            ms = new Musteri(); 
            od = new Odeme();
        }
        private void DisplayOdemeData()
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            string query = "SELECT * FROM satis";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    odemeGridView1.DataSource = dataTable;
                }
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtTarih_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTutar_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSatId_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void TamamBtn_Click(object sender, EventArgs e)
        {
            string constring = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            MySqlConnection con = new MySqlConnection(constring);
            con.Open();
            int foreignKey1 = urun.UrunId;
            int foreignKey2 = ms.MusteriId;
            int foreignKey3 = od.SatisId;
            // ,urunId,musteriId,satisTarih
            //@urunId, @musteriId,

            string insertIntoTable = "INSERT INTO satis ( satisId,urunId,musteriId,satisTarih)" +
                " VALUES (@satisId,@urunId, @musteriId, @satisTarih)";
            using (MySqlCommand cmd = new MySqlCommand(insertIntoTable, con))
            {
                cmd.Parameters.AddWithValue("@satisId",txtSID.Text);
                cmd.Parameters.AddWithValue("@urunId",txtUId.Text );
                cmd.Parameters.AddWithValue("@musteriId",txtMId.Text );
                cmd.Parameters.AddWithValue("@satisTarih",txtST.Value );

               


                int rowsAffected = cmd.ExecuteNonQuery();
                MessageBox.Show("Satis başarıyla eklendi");
            }
            DisplayOdemeData();
        }

        private void DuzenleBtn_Click(object sender, EventArgs e)
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                
                string query = "UPDATE satis SET satisIdParam=@satisIdParam, urunIdParam= @urunIdParam, musteriIdParam  = @musteriIdParam,satisTarihParam=@satisTarihParam";

                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@satisIdParam", Convert.ToInt32(txtSID.Text));
                    cmd.Parameters.AddWithValue("@urunIdParam", txtUId.Text);
                    cmd.Parameters.AddWithValue("@musteriIdParam", txtMId.Text);
                    cmd.Parameters.AddWithValue("@satisTarihParam", txtST.Value);
                    
                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Satis updated successfully.");

                        DisplayOdemeData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update Urun.");
                    }
                }
            }
        }

        private void SatisFrm_Load(object sender, EventArgs e)
        {
            DisplayOdemeData();
        }
        private int GetSatisId()
        {

            int urunId = 0;


            if (odemeGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = odemeGridView1.SelectedRows[0];
                urunId = Convert.ToInt32(selectedRow.Cells[0].Value);

                txtSID.Text = urunId.ToString();


            }



            return urunId;
        }


        private void SilBtn_Click(object sender, EventArgs e)
        {
            int musID = GetSatisId();
            txtSID.Text = musID.ToString();

            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = "DELETE FROM satis WHERE satisId = @satisId";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@satisId", musID);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Satis deleted successfully.");
                        DisplayOdemeData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete Urun.");
                    }
                }
            }
        }
    }
}

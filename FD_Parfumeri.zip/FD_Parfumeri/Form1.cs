﻿namespace FD_Parfumeri
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void EkleBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void urunBtn_Click(object sender, EventArgs e)
        {
            UrunFrm frm = new UrunFrm();
            frm.Show();
        }

        private void muBtn_Click(object sender, EventArgs e)
        {
            MustriForm frm = new MustriForm();
            frm.Show();
        }

        private void odemBtn_Click(object sender, EventArgs e)
        {
           OdemeFrm frm = new OdemeFrm();
            frm.Show();
        }

        private void SatisBtn_Click(object sender, EventArgs e)
        {
            SatisFrm frm = new SatisFrm();
            frm.Show();
        }
    }
}
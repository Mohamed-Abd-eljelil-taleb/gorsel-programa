﻿namespace FD_Parfumeri
{
    partial class OdemeFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtSatId = new System.Windows.Forms.TextBox();
            this.txtTutar = new System.Windows.Forms.TextBox();
            this.TamamBtn = new System.Windows.Forms.Button();
            this.odemeGridView1 = new System.Windows.Forms.DataGridView();
            this.IptalBtn = new System.Windows.Forms.Button();
            this.DuzenleBtn = new System.Windows.Forms.Button();
            this.SilBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTarih = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.odemeGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(82, 12);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(159, 23);
            this.txtID.TabIndex = 0;
            // 
            // txtSatId
            // 
            this.txtSatId.Location = new System.Drawing.Point(82, 51);
            this.txtSatId.Name = "txtSatId";
            this.txtSatId.Size = new System.Drawing.Size(159, 23);
            this.txtSatId.TabIndex = 0;
            // 
            // txtTutar
            // 
            this.txtTutar.Location = new System.Drawing.Point(82, 90);
            this.txtTutar.Name = "txtTutar";
            this.txtTutar.Size = new System.Drawing.Size(159, 23);
            this.txtTutar.TabIndex = 0;
            // 
            // TamamBtn
            // 
            this.TamamBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.TamamBtn.Location = new System.Drawing.Point(59, 165);
            this.TamamBtn.Name = "TamamBtn";
            this.TamamBtn.Size = new System.Drawing.Size(75, 33);
            this.TamamBtn.TabIndex = 1;
            this.TamamBtn.Text = "Tamam";
            this.TamamBtn.UseVisualStyleBackColor = false;
            this.TamamBtn.Click += new System.EventHandler(this.TamamBtn_Click);
            // 
            // odemeGridView1
            // 
            this.odemeGridView1.AllowUserToAddRows = false;
            this.odemeGridView1.AllowUserToDeleteRows = false;
            this.odemeGridView1.AllowUserToResizeColumns = false;
            this.odemeGridView1.BackgroundColor = System.Drawing.SystemColors.MenuHighlight;
            this.odemeGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.odemeGridView1.Dock = System.Windows.Forms.DockStyle.Right;
            this.odemeGridView1.Location = new System.Drawing.Point(247, 0);
            this.odemeGridView1.Name = "odemeGridView1";
            this.odemeGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.odemeGridView1.RowTemplate.Height = 25;
            this.odemeGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.odemeGridView1.Size = new System.Drawing.Size(535, 450);
            this.odemeGridView1.TabIndex = 2;
            // 
            // IptalBtn
            // 
            this.IptalBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.IptalBtn.Location = new System.Drawing.Point(166, 165);
            this.IptalBtn.Name = "IptalBtn";
            this.IptalBtn.Size = new System.Drawing.Size(75, 33);
            this.IptalBtn.TabIndex = 1;
            this.IptalBtn.Text = "Iptal";
            this.IptalBtn.UseVisualStyleBackColor = false;
            // 
            // DuzenleBtn
            // 
            this.DuzenleBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.DuzenleBtn.Location = new System.Drawing.Point(59, 245);
            this.DuzenleBtn.Name = "DuzenleBtn";
            this.DuzenleBtn.Size = new System.Drawing.Size(75, 33);
            this.DuzenleBtn.TabIndex = 1;
            this.DuzenleBtn.Text = "Duzenle";
            this.DuzenleBtn.UseVisualStyleBackColor = false;
            this.DuzenleBtn.Click += new System.EventHandler(this.DuzenleBtn_Click);
            // 
            // SilBtn
            // 
            this.SilBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SilBtn.Location = new System.Drawing.Point(166, 245);
            this.SilBtn.Name = "SilBtn";
            this.SilBtn.Size = new System.Drawing.Size(75, 33);
            this.SilBtn.TabIndex = 1;
            this.SilBtn.Text = "Sil";
            this.SilBtn.UseVisualStyleBackColor = false;
            this.SilBtn.Click += new System.EventHandler(this.SilBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Odeme ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Satis ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Odeme Tutar";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(2, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tarih";
            // 
            // txtTarih
            // 
            this.txtTarih.Location = new System.Drawing.Point(68, 129);
            this.txtTarih.Name = "txtTarih";
            this.txtTarih.Size = new System.Drawing.Size(173, 23);
            this.txtTarih.TabIndex = 4;
            // 
            // OdemeFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(782, 450);
            this.Controls.Add(this.txtTarih);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.odemeGridView1);
            this.Controls.Add(this.SilBtn);
            this.Controls.Add(this.DuzenleBtn);
            this.Controls.Add(this.IptalBtn);
            this.Controls.Add(this.TamamBtn);
            this.Controls.Add(this.txtTutar);
            this.Controls.Add(this.txtSatId);
            this.Controls.Add(this.txtID);
            this.Name = "OdemeFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OdemeFrm";
            this.Load += new System.EventHandler(this.OdemeFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.odemeGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtID;
        private TextBox txtSatId;
        private TextBox txtTutar;
        private Button TamamBtn;
        private DataGridView odemeGridView1;
        private Button IptalBtn;
        private Button DuzenleBtn;
        private Button SilBtn;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private DateTimePicker txtTarih;
    }
}
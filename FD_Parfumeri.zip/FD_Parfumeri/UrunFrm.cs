﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static FD_Parfumeri.Varleklar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FD_Parfumeri
{
    public partial class UrunFrm : Form

        
    {
        Urun urun { get; set; }
        
        string server = "127.0.0.1";
        string uid = "19675245019";
        string password = "19675245019";
        string database = "19675245019_frateliParfumleri";

        public UrunFrm()
        {
            InitializeComponent();
           
        }
        
        private void TmmBtn_Click(object sender, EventArgs e)
        {
            string constring = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            MySqlConnection con = new MySqlConnection(constring);
            con.Open();

            

            string insertIntoTable = "INSERT INTO urun (urunId, urunAd, urunStok, urunFiyat) VALUES (@urunId, @urunAd, @urunStok, @urunFiyat)";
            using (MySqlCommand cmd = new MySqlCommand(insertIntoTable, con))
            {
                cmd.Parameters.AddWithValue("@urunId", Convert.ToInt32(txtID.Text));
                cmd.Parameters.AddWithValue("@urunAd", txtAd.Text);
                cmd.Parameters.AddWithValue("@urunStok", txtStock.Value);
                cmd.Parameters.AddWithValue("@urunFiyat", txtFiyat.Value);
                
                int rowsAffected = cmd.ExecuteNonQuery();
                MessageBox.Show("ürün başarıyla eklendi");
            }
            DisplayUrunData();


        }
        private void DisplayUrunData()
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            string query = "SELECT * FROM urun";  

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    urunGridView1.DataSource = dataTable;
                }
            }
        }
        
        private void CancelBtn_Click(object sender, EventArgs e)
        {

        }
       
        private int GetUrunId()
        {

            int urunId =0;


            if (urunGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = urunGridView1.SelectedRows[0];
                urunId = Convert.ToInt32(selectedRow.Cells[0].Value);
          
                txtID.Text = urunId.ToString();
                
                
            }



            return urunId;
        }


        private void UrunFrm_Load(object sender, EventArgs e)
        {
            DisplayUrunData();
        }

        private void DuzenleBtn_Click(object sender, EventArgs e)
        {
          
            int urunId = Convert.ToInt32(txtID.Text); // Implement the method to retrieve the UrunId
            string urunAd = txtAd.Text;
            int urunStok = Convert.ToInt32(txtStock.Text);
            decimal urunFiyat = Convert.ToDecimal(txtFiyat.Text);

            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                int urunID = GetUrunId();
                string query = "UPDATE urun SET UrunAd = @UrunAd, UrunStok = @UrunStok, UrunFiyat = @UrunFiyat WHERE UrunId = "+ urunID;

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UrunId", urunId);
                    command.Parameters.AddWithValue("@UrunAd", urunAd);
                    command.Parameters.AddWithValue("@UrunStok", urunStok);
                    command.Parameters.AddWithValue("@UrunFiyat", urunFiyat);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Urun updated successfully.");
                        // Perform any additional actions or refresh the form as needed
                        DisplayUrunData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update Urun.");
                    }
                }
            }
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            int urunId = GetUrunId();
            txtID.Text = urunId.ToString();

            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = "DELETE FROM urun WHERE UrunId = @UrunId";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UrunId", urunId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Urun deleted successfully.");
                        DisplayUrunData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete Urun.");
                    }
                }
            }
        }
       
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Check if a valid row is clicked
            {
                DataGridViewRow selectedRow = urunGridView1.Rows[e.RowIndex];

                // Assuming you have TextBox controls named txtUrunId, txtUrunAd, txtUrunStok, and txtUrunFiyat

                // Retrieve the values from the selected row and display them in the TextBoxes
                txtID.Text = selectedRow.Cells["UrunId"].Value.ToString();
                txtAd.Text = selectedRow.Cells["UrunAd"].Value.ToString();
                txtStock.Text = selectedRow.Cells["UrunStok"].Value.ToString();
                txtFiyat.Text = selectedRow.Cells["UrunFiyat"].Value.ToString();
            }
        }

        private void UrunFrm_Load_1(object sender, EventArgs e)
        {

        }
    }

}

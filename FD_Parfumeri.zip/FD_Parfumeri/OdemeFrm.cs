﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static FD_Parfumeri.Varleklar;

namespace FD_Parfumeri
{
    public partial class OdemeFrm : Form
    {
        Satis satis { get; set; }
        string server = "127.0.0.1";
        string uid = "19675245019";
        string password = "19675245019";
        string database = "19675245019_frateliParfumleri";
        public OdemeFrm()
        {
            InitializeComponent();
        }
        private void DisplayOdemeData()
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            string query = "SELECT * FROM odeme";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    odemeGridView1.DataSource = dataTable;
                }
            }
        }

        private void TamamBtn_Click(object sender, EventArgs e)
        {
            string constring = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;
            MySqlConnection con = new MySqlConnection(constring);
            con.Open();



            string insertIntoTable = "INSERT INTO odeme (odemeId, satisId, odemeTutar, odemeTarih)" +
                " VALUES (@odemeId, @satisiId, @odemeTutar, @odemeTarih)";
            using (MySqlCommand cmd = new MySqlCommand(insertIntoTable, con))
            {
                cmd.Parameters.AddWithValue("@odemeId", Convert.ToInt32(txtID.Text));
                cmd.Parameters.AddWithValue("@satisiId", txtSatId.Text);
                cmd.Parameters.AddWithValue("@odemeTutar", txtTutar.Text);
                cmd.Parameters.AddWithValue("@odemeTarih", txtTarih.Value);


                int rowsAffected = cmd.ExecuteNonQuery();
                MessageBox.Show("ürün başarıyla eklendi");
            }
            DisplayOdemeData();

        
    
    }

        private void DuzenleBtn_Click(object sender, EventArgs e)
        {
            string connectionString = "server=" + server + ";uid=" + uid + ";password=" + password + ";database=" + database;

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {

                string query = "UPDATE odeme SET  satisIdParam= @satisIdParam, odemeTutarParam  = @odemeTutarParam,odemeTarihParam=@odemeTarihParam";

                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    //cmd.Parameters.AddWithValue("@odemeIdParam", Convert.ToInt32(txtID.Text));
                    cmd.Parameters.AddWithValue("@satisIdParam", txtSatId.Text);
                    cmd.Parameters.AddWithValue("@odemeTutarParam", txtTutar.Text);
                    cmd.Parameters.AddWithValue("@odemeTarihParam", txtTarih.Value);

                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Musteri updated successfully.");

                        DisplayOdemeData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update Urun.");
                    }
                }
            }
        }

        private void SilBtn_Click(object sender, EventArgs e)
        {

        }

        private void OdemeFrm_Load(object sender, EventArgs e)
        {
            DisplayOdemeData();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FD_Parfumeri
{
    internal class Varleklar
    {
        public class Urun
        {
            public int UrunId { get; set; }
            public string UrunAd { get; set; }
            public int UrunStok { get; set; }
            public decimal UrunFiyat { get; set; }
        }
        public class Musteri
        {
            public int MusteriId { get; set; }
            public string MusteriAd { get; set; }
            public string MusteriSoyad { get; set; }
            public string MusteriTelefon { get; set; }
            public string MusteriEmail { get; set; }
            
        }
        public class Odeme
        {
            public int OdemeId { get; set; }
            public int SatisId { get; set; }
            public decimal OdemeMiktari { get; set; }
            public DateTime OdemeTarihi { get; set; }
           
           
        }
        public class Satis
        {
            public int SatisId { get; set; }
            public int MusteriId { get; set; }
            public int UrunId { get; set; }
            public DateTime SatisTarihi { get; set; }
           
        }


    }
}

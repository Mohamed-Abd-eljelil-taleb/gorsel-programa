﻿namespace FD_Parfumeri
{
    partial class MustriForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtAD = new System.Windows.Forms.TextBox();
            this.txtTelefon = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.tamamBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.duzenleBtn = new System.Windows.Forms.Button();
            this.silBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.musGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.musGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtID
            // 
            this.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtID.Location = new System.Drawing.Point(82, 12);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(176, 23);
            this.txtID.TabIndex = 0;
            // 
            // txtAD
            // 
            this.txtAD.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAD.Location = new System.Drawing.Point(82, 57);
            this.txtAD.Name = "txtAD";
            this.txtAD.Size = new System.Drawing.Size(176, 23);
            this.txtAD.TabIndex = 0;
            // 
            // txtTelefon
            // 
            this.txtTelefon.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTelefon.Location = new System.Drawing.Point(82, 150);
            this.txtTelefon.Name = "txtTelefon";
            this.txtTelefon.Size = new System.Drawing.Size(176, 23);
            this.txtTelefon.TabIndex = 0;
            // 
            // txtSoyad
            // 
            this.txtSoyad.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSoyad.Location = new System.Drawing.Point(82, 106);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(176, 23);
            this.txtSoyad.TabIndex = 0;
            // 
            // txtAdd
            // 
            this.txtAdd.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAdd.Location = new System.Drawing.Point(72, 200);
            this.txtAdd.Multiline = true;
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(186, 88);
            this.txtAdd.TabIndex = 0;
            // 
            // tamamBtn
            // 
            this.tamamBtn.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tamamBtn.Location = new System.Drawing.Point(66, 312);
            this.tamamBtn.Name = "tamamBtn";
            this.tamamBtn.Size = new System.Drawing.Size(88, 37);
            this.tamamBtn.TabIndex = 1;
            this.tamamBtn.Text = "Tamam";
            this.tamamBtn.UseVisualStyleBackColor = false;
            this.tamamBtn.Click += new System.EventHandler(this.tamamBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.BackColor = System.Drawing.SystemColors.HotTrack;
            this.cancelBtn.Location = new System.Drawing.Point(170, 312);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(88, 37);
            this.cancelBtn.TabIndex = 1;
            this.cancelBtn.Text = "İptal";
            this.cancelBtn.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button3.Location = new System.Drawing.Point(170, 372);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 37);
            this.button3.TabIndex = 1;
            this.button3.Text = "button1";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // duzenleBtn
            // 
            this.duzenleBtn.BackColor = System.Drawing.SystemColors.HotTrack;
            this.duzenleBtn.Location = new System.Drawing.Point(66, 372);
            this.duzenleBtn.Name = "duzenleBtn";
            this.duzenleBtn.Size = new System.Drawing.Size(88, 37);
            this.duzenleBtn.TabIndex = 1;
            this.duzenleBtn.Text = "Duzenle";
            this.duzenleBtn.UseVisualStyleBackColor = false;
            this.duzenleBtn.Click += new System.EventHandler(this.duzenleBtn_Click_1);
            // 
            // silBtn
            // 
            this.silBtn.BackColor = System.Drawing.SystemColors.HotTrack;
            this.silBtn.Location = new System.Drawing.Point(170, 372);
            this.silBtn.Name = "silBtn";
            this.silBtn.Size = new System.Drawing.Size(88, 37);
            this.silBtn.TabIndex = 1;
            this.silBtn.Text = "Sil";
            this.silBtn.UseVisualStyleBackColor = false;
            this.silBtn.Click += new System.EventHandler(this.silBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ad :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Soyad :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Email :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Adres :";
            // 
            // musGridView1
            // 
            this.musGridView1.AllowUserToAddRows = false;
            this.musGridView1.AllowUserToDeleteRows = false;
            this.musGridView1.BackgroundColor = System.Drawing.SystemColors.MenuHighlight;
            this.musGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.musGridView1.Dock = System.Windows.Forms.DockStyle.Right;
            this.musGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.musGridView1.GridColor = System.Drawing.SystemColors.InactiveBorder;
            this.musGridView1.Location = new System.Drawing.Point(264, 0);
            this.musGridView1.Name = "musGridView1";
            this.musGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.musGridView1.RowTemplate.Height = 25;
            this.musGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.musGridView1.Size = new System.Drawing.Size(547, 450);
            this.musGridView1.TabIndex = 3;
            // 
            // MustriForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(811, 450);
            this.Controls.Add(this.musGridView1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.duzenleBtn);
            this.Controls.Add(this.silBtn);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.tamamBtn);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.txtAdd);
            this.Controls.Add(this.txtTelefon);
            this.Controls.Add(this.txtAD);
            this.Controls.Add(this.txtID);
            this.Name = "MustriForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MuştriForm";
            this.Load += new System.EventHandler(this.MustriForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.musGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtID;
        private TextBox txtAD;
        private TextBox txtTelefon;
        private TextBox txtSoyad;
        private TextBox txtAdd;
        private Button tamamBtn;
        private Button cancelBtn;
        private Button button3;
        private Button duzenleBtn;
        private Button silBtn;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private DataGridView musGridView1;
    }
}
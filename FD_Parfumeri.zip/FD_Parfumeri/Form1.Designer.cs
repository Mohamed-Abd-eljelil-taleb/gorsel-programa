﻿namespace FD_Parfumeri
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.urunBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.odemeBtn = new System.Windows.Forms.Button();
            this.muBtn = new System.Windows.Forms.Button();
            this.satBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // urunBtn
            // 
            this.urunBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            resources.ApplyResources(this.urunBtn, "urunBtn");
            this.urunBtn.Name = "urunBtn";
            this.urunBtn.UseVisualStyleBackColor = false;
            this.urunBtn.Click += new System.EventHandler(this.urunBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.urunBtn_Click);
            // 
            // odemeBtn
            // 
            this.odemeBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            resources.ApplyResources(this.odemeBtn, "odemeBtn");
            this.odemeBtn.Name = "odemeBtn";
            this.odemeBtn.UseVisualStyleBackColor = false;
            this.odemeBtn.Click += new System.EventHandler(this.odemBtn_Click);
            // 
            // muBtn
            // 
            this.muBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            resources.ApplyResources(this.muBtn, "muBtn");
            this.muBtn.Name = "muBtn";
            this.muBtn.UseVisualStyleBackColor = false;
            this.muBtn.Click += new System.EventHandler(this.muBtn_Click);
            // 
            // satBtn
            // 
            this.satBtn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            resources.ApplyResources(this.satBtn, "satBtn");
            this.satBtn.Name = "satBtn";
            this.satBtn.UseVisualStyleBackColor = false;
            this.satBtn.Click += new System.EventHandler(this.SatisBtn_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.muBtn);
            this.Controls.Add(this.satBtn);
            this.Controls.Add(this.odemeBtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.urunBtn);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Button urunBtn;
        private Button button1;
        private Button odemeBtn;
        private Button muBtn;
        private Button satBtn;
    }
}
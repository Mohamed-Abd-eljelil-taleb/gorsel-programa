﻿namespace FD_Parfumeri
{
    partial class SatisFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.odemeGridView1 = new System.Windows.Forms.DataGridView();
            this.SilBtn = new System.Windows.Forms.Button();
            this.DuzenleBtn = new System.Windows.Forms.Button();
            this.IptalBtn = new System.Windows.Forms.Button();
            this.TamamBtn = new System.Windows.Forms.Button();
            this.txtMId = new System.Windows.Forms.TextBox();
            this.txtUId = new System.Windows.Forms.TextBox();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtST = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.odemeGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // odemeGridView1
            // 
            this.odemeGridView1.AllowUserToAddRows = false;
            this.odemeGridView1.AllowUserToDeleteRows = false;
            this.odemeGridView1.AllowUserToResizeColumns = false;
            this.odemeGridView1.BackgroundColor = System.Drawing.SystemColors.MenuHighlight;
            this.odemeGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.odemeGridView1.Dock = System.Windows.Forms.DockStyle.Right;
            this.odemeGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.odemeGridView1.Location = new System.Drawing.Point(243, 0);
            this.odemeGridView1.Name = "odemeGridView1";
            this.odemeGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.odemeGridView1.RowTemplate.Height = 25;
            this.odemeGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.odemeGridView1.Size = new System.Drawing.Size(543, 450);
            this.odemeGridView1.TabIndex = 11;
            // 
            // SilBtn
            // 
            this.SilBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SilBtn.Location = new System.Drawing.Point(151, 245);
            this.SilBtn.Name = "SilBtn";
            this.SilBtn.Size = new System.Drawing.Size(75, 33);
            this.SilBtn.TabIndex = 7;
            this.SilBtn.Text = "Sil";
            this.SilBtn.UseVisualStyleBackColor = false;
            this.SilBtn.Click += new System.EventHandler(this.SilBtn_Click);
            // 
            // DuzenleBtn
            // 
            this.DuzenleBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.DuzenleBtn.Location = new System.Drawing.Point(44, 245);
            this.DuzenleBtn.Name = "DuzenleBtn";
            this.DuzenleBtn.Size = new System.Drawing.Size(75, 33);
            this.DuzenleBtn.TabIndex = 8;
            this.DuzenleBtn.Text = "Duzenle";
            this.DuzenleBtn.UseVisualStyleBackColor = false;
            this.DuzenleBtn.Click += new System.EventHandler(this.DuzenleBtn_Click);
            // 
            // IptalBtn
            // 
            this.IptalBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.IptalBtn.Location = new System.Drawing.Point(151, 165);
            this.IptalBtn.Name = "IptalBtn";
            this.IptalBtn.Size = new System.Drawing.Size(75, 33);
            this.IptalBtn.TabIndex = 9;
            this.IptalBtn.Text = "Iptal";
            this.IptalBtn.UseVisualStyleBackColor = false;
            // 
            // TamamBtn
            // 
            this.TamamBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.TamamBtn.Location = new System.Drawing.Point(44, 165);
            this.TamamBtn.Name = "TamamBtn";
            this.TamamBtn.Size = new System.Drawing.Size(75, 33);
            this.TamamBtn.TabIndex = 10;
            this.TamamBtn.Text = "Tamam";
            this.TamamBtn.UseVisualStyleBackColor = false;
            this.TamamBtn.Click += new System.EventHandler(this.TamamBtn_Click);
            // 
            // txtMId
            // 
            this.txtMId.Location = new System.Drawing.Point(78, 88);
            this.txtMId.Name = "txtMId";
            this.txtMId.Size = new System.Drawing.Size(159, 23);
            this.txtMId.TabIndex = 4;
            this.txtMId.TextChanged += new System.EventHandler(this.txtTutar_TextChanged);
            // 
            // txtUId
            // 
            this.txtUId.Location = new System.Drawing.Point(78, 49);
            this.txtUId.Name = "txtUId";
            this.txtUId.Size = new System.Drawing.Size(159, 23);
            this.txtUId.TabIndex = 5;
            this.txtUId.TextChanged += new System.EventHandler(this.txtSatId_TextChanged);
            // 
            // txtSID
            // 
            this.txtSID.Location = new System.Drawing.Point(78, 10);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(159, 23);
            this.txtSID.TabIndex = 6;
            this.txtSID.TextChanged += new System.EventHandler(this.txtID_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "satis ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 12;
            this.label2.Text = "Urun ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Musteri ID";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "Satis Tarihi";
            // 
            // txtST
            // 
            this.txtST.Location = new System.Drawing.Point(78, 127);
            this.txtST.Name = "txtST";
            this.txtST.Size = new System.Drawing.Size(159, 23);
            this.txtST.TabIndex = 13;
            // 
            // SatisFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(786, 450);
            this.Controls.Add(this.txtST);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.odemeGridView1);
            this.Controls.Add(this.SilBtn);
            this.Controls.Add(this.DuzenleBtn);
            this.Controls.Add(this.IptalBtn);
            this.Controls.Add(this.TamamBtn);
            this.Controls.Add(this.txtMId);
            this.Controls.Add(this.txtUId);
            this.Controls.Add(this.txtSID);
            this.Name = "SatisFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SatisFrm";
            this.Load += new System.EventHandler(this.SatisFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.odemeGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView odemeGridView1;
        private Button SilBtn;
        private Button DuzenleBtn;
        private Button IptalBtn;
        private Button TamamBtn;
        private TextBox txtMId;
        private TextBox txtUId;
        private TextBox txtSID;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private DateTimePicker txtST;
    }
}